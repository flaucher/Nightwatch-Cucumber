/// <reference path="../helpers/vs-intellisense-definitions.js" /> 
module.exports = {
      //'@disabled': true, // This will prevent the test module from running.
    "Test Name": function (browser)
    { /// <param name="browser" type="_Browser">

        // Intellisense success!
        browser.end;
    }
}