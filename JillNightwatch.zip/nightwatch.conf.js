
module.exports = (function (settings) {
    //settings.test_workers = true;
    //<reference path="/NODEJS/workSpace/NightWatchDemo/vs-intellisense-definitions.js" />
    return settings;
})(require('./nightwatch.json'));